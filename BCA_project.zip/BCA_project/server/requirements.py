python-telegram-bot==20.7
Flask==3.0.0
flask-cors==4.0.0